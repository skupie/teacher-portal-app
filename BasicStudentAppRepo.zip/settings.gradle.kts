
rootProject.name = "BasicStudentApp"
include(":app")
